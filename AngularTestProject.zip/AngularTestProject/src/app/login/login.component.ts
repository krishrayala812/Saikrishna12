import { error } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms'
import { LoginService } from '../Service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  response = false;
  constructor(private formBulider: FormBuilder,
    private loginService: LoginService) {
    this.loginService.loginSuccessful = false;
    this.loginForm = this.formBulider.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loginForm = this.formBulider.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  get f() { return this.loginForm.controls; }

  OnSubmit() {
    this.submitted = true;
    this.loginService.login(this.f.username.value, this.f.password.value)
      .then(data => { console.log(data.loginSuccessful)},
        error => { console.log(error)});
    
  }

}
