import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService implements ILoginResult {

  constructor() { }
    loginSuccessful: boolean = false;

  login(username: string, password: string):Promise<ILoginResult> {
    if (username == "admin" && password == "admin@123") {
      return new Promise<ILoginResult>(() => { true });
    }
    return new Promise<ILoginResult>(() => { false });
  }
}


export interface ILoginResult {
  loginSuccessful: boolean;
}
